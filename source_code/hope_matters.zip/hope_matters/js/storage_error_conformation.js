function confirm_storage_error() {
	
	alert("I am fully aware that not resolving the server's storage issue will likely result in losing all data.");
	
}